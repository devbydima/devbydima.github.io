Whoa, What Changed? by devbydima: press kit
Package name: devbydima.whatchanged
Google Play: https://play.google.com/store/apps/details?id=devbydima.whatchanged
Game page:   https://devbydima.github.io/whatchanged/
Press page:  https://devbydima.github.io/press/
Contact:     devbydima@gmail.com
